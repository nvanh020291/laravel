<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class BlogController extends Controller
{

    public function __construct()
    {

    }

    public function index()
    {
        $datas = array(
            'name' => 'Nguyen Van Anh',
            'age' => 20 ,
        ) ;
        return view('blog', ['datas' => $datas]);
    }

    public function getList()
    {
        return __METHOD__;
    }
}
