<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use  App\Model\Info;

class UserController extends Controller
{

    public function __construct()
    {
    }

    public function index(Request $request)
    {
        $info = Info::where('id', 1)->first()->select();
        echo '<pre>' ;
        print_r($info) ;
        exit ;
    }
    public function store(){
        $info   = new Info ;
        $info->find(['name' => 'Nguyen van anh' , 'age' => 300]);
        $info->save();
    }

    public function getList()
    {
        return __METHOD__;
    }
}
